<!doctype html>
<html>
<head>
    <title>E-shop </title>
	<link rel="stylesheet" href="eshop.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<div class="header">

		<h1> E-shop </h1>

</div>
<div class="topnav">
  <a class="active" href="eshopmain.php">Home</a>
  <a href="contact.php">Contact</a>

  <a href="view_users.php">Users </a>
 
  <a href="technology.php">Tεχνολογια </a>
   <a href="hxos.php">Ηχος </a>
 <a href="photo.php">Φωτογραφικες Μηχανες </a>
   

  <div class="login-container">
    <form action="login.php">
     
      <button type="submit" name="submitted">Login</button>
    </form>
  </div>
  <div class="kalathi">
	  <a  href="cart.php" >Καλαθι</a>
	 </div>
	 <div class="eggrafh">
	 <a href="signup.php">Sign up</a>
	 </div>
	
 <div class="logout-container">
  <b>  <a href="logout.php" name="submitted">Logout</a></b>
     
  </div>	
 
<div class="search-container">
<form action="search.php" method="GET">
    <input type="text" placeholder="Πληκτρολογειστε ενα ονομα προιοντος..." name="query" />
    <button type="submit" value="Search" <i class="fa fa-search"></i></button>
</form>
  </div>
</div>
<br>
<h2><i><b>BEST SELLERS!!!</b></i></h2>
<div class="best-c">
<div class="best-i"><a href="technology.php"><img src="lg.jpg" alt="lg"  style="width:300px;height:200px;"></a><p><b>LG 44" 149$</b></p></div>
<div class="best-i"><a href="hxos.php"><img src="jbl.jpeg" alt="jbl" style="width:300px;height:200px;" ></a><p><b>JBL ηχειο 22$ </B></p></div></a>
</div><br><br>
<p>
<h2><i><b>CRAZY ΕΚΠΤΩΣΕΙΣ ΣΗΜΕΡΑ!!!</b></i></h2></p>
<div class="best-b">
<div class="best-i"><a href="technology.php"><img src="razer.jpg" alt="razer"  style="width:300px;height:200px;"></a><p><b>Razer BlackWindow Πληκτρολογιο ΜΟΝΟ 69$</b></p></div>
<div class="best-i"><a href="photo.php"><img src="canon.jpg" alt="canon" style="width:300px;height:200px;" ></a><p><b>Φωτογραφικη Μηχανη Canon Ixus 190 ΜΟΝΟ 159$ </B></p></div></a>
</div>
</body>
<!-- Script 3.3 - footer.html -->
	<!-- End of the page-specific content. --></div>
	
	<div class="footer">
		<p>Copyright &copy; <a> 2020 | Designed by Dimos Geo</a> | Sponsored by E-shops.gr</a> | Valid <a href="http://jigsaw.w3.org/css-validator/">CSS</a> &amp; <a href="http://validator.w3.org/">XHTML</a></p>
	</div>
</body>
</html>

</html>


