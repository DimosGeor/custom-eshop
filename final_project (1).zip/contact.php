<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>CONTACT </title>
	
	<style>
 body{
  background-image: url('cont.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}
a:hover{
background-color: yellow;
}
img:hover{
background-color: yellow;
transform: scaleX(-1);
}
img{
border-radius: 50%;
}
h2 {
padding:10px;
border:1px solid black;
width:20%;
}

h1{
text-align:center;
}
  p{
  text-align:right;
  position:absolute;
  top: 80px;
  right: 0;
  width: 200px;
  height: 100px;
  
  }
 map{
position: relative;
    left: 600px;
	margin:10px;
	padding:10px;
 }	
</style>
</head>
<body>

<h1> <i>CONTACT PAGE</i> </h1>
 <a href="https://www.facebook.com/dimos.georr">
<img border="0" alt="facebook" src="fb.jpg" width="100" height="100">
</a>
 <a href="https://www.instagram.com/dimos_geor/?hl=el">
<img border="0" alt="instagram" src="ig.jpeg" width="100" height="100">
</a>
 <a href="https://mail.google.com/mail/u/0/#inbox">
<img border="0" alt="gmail" src="gm.png" width="100" height="100">
</a>
<div>
<h2> OR call us +306969697812 </h2>
</div>
 <br>
 <p>
 <a href="eshopmain.php">
 <img border="0" alt="main" src="home.png" width="100" height="100" >
</p>
<div class="map">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3716966.4189081215!2d23.029495069160042!3d38.57604613942476!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x184b5aa21f631429!2zRS1zaG9wIHBvaW50IM6Sz4zOu86_z4I!5e0!3m2!1sel!2sgr!4v1591209338719!5m2!1sel!2sgr" width="500" height="300" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
</div>
</body>
</html>